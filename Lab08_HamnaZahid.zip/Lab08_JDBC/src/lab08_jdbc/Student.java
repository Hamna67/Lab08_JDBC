/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab08_jdbc;
import java.nio.charset.Charset;
import java.sql.CallableStatement;
import java.util.Random;

/**
 *
 * @author ABC
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ABC
 */
public class Student {
    Connection con;
    public Student()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3307/lab8_student", "root", "deutrium2");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
    public String getRandomName()
    {
  //help taken online
        int lLimit = 97; // letter 'a'
        int rLimit = 122; // letter 'z'
        int stringLength = 6;
        Random random = new Random();
        StringBuilder buff = new StringBuilder(stringLength);
        for (int i = 0; i < stringLength; i++) {
            int randomLimitedInt = lLimit + (int) (random.nextFloat() * (rLimit - lLimit + 1));
            buff.append((char) randomLimitedInt);
        }
        String generatedString = buff.toString();
        String output = generatedString.substring(0, 1).toUpperCase() + generatedString.substring(1);
      //  System.out.println(output);
        return output;
    }
    
    //function for returnig random numbers from 1 to 5000
    public int getRandomNumber()
    {
        Random random = new Random();
        return random.nextInt(5000) + 1;
    }
    //function for returing random numbers from 1 to 8
    public int getRandomSemester()
    {
         Random random = new Random();
        return random.nextInt(8) + 1;
    }
    
    //function for returing the number of rows currently in db table
    public int getRowNum () throws SQLException
    {
        int count=0;
        Statement statement = con.createStatement();
          try
        {
        
        ResultSet rs = statement.executeQuery("select count(*) from lab8_student.students;");
        rs.next();
        count = rs.getInt(1);
        
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
        finally
        {
            statement.close();
            return count;
        }
    }
    
    //function for truncating the database table
   public void truncate_students() throws SQLException
    {
        Statement statement = con.createStatement();
         try
        {
       int rs = statement.executeUpdate("Truncate lab8_student.students;");
        
        
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            statement.close();
        }
    }
   
   //function for inserting 5000 entries into the db using create statements
    public void insert_statement(boolean acommit) throws SQLException
    {       
         Statement statement = con.createStatement();
        try
        {
         con.setAutoCommit(acommit);
        String name = "";
        int reg = 0;
        int semester = 0;
        String address = "House #6, Street5, E-8, Isl";
        int rs =0;
        for(int i=0; i < 5000; i++)
        {
        name = getRandomName();
        reg = getRandomNumber();
        semester = getRandomSemester();
       
        rs = statement.executeUpdate("Insert into lab8_student.students(Name, RegistrationNumber,Semester,Address) values('"+name+"','"+reg+"','"+semester+"','"+address+"');");
        
        }
       
        if(acommit == false)
        {
            con.commit();
        }
      
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
           statement.close();
        }
    }
    
    //function for inserting 5000 entries into the db table using prepared statemetns
    public void insert_PreparedStatement(boolean acommit) throws SQLException
    {   
        String SQL = "Insert into lab8_student.students(Name, RegistrationNumber,Semester,Address) values(?,?,?,?);";
         PreparedStatement prstmt = con.prepareStatement(SQL);
        try
        {
        con.setAutoCommit(acommit);
        
       
        String name = "";
      
        int reg = 0;
        int semester = 0;
        String address = "House #6, Street5, E-8, Isl";
        int rs =0;
      
        for(int i=0; i < 5000; i++)
        {
        name = getRandomName();
            reg = getRandomNumber();
            semester = getRandomSemester();

            prstmt.setString(1,name);
            prstmt.setInt(2,reg);
            prstmt.setInt(3,semester);
            prstmt.setString(4,address);

            rs = prstmt.executeUpdate();
        
        }
     
        if(acommit == false)
        {
            con.commit();
        }
      
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
             prstmt.close();
        }
    }
    
    //function for batch inserting 5000 entires into the db table
    public void insert_Batch(boolean acommit) throws SQLException
    {       
         String SQL = "Insert into lab8_student.students(Name, RegistrationNumber,Semester,Address) values(?,?,?,?);";
        PreparedStatement prstmt = con.prepareStatement(SQL);
        try
        {
        con.setAutoCommit(acommit);
       
        String name = "";
      
        int reg = 0;
        int semester = 0;
        String address = "House #6, Street5, E-8, Isl";
        int[] rs ;
      
        for(int i=0; i < 10; i++)
        {
        name = getRandomName();
            reg = getRandomNumber();
            semester = getRandomSemester();

            prstmt.setString(1,name);
            prstmt.setInt(2,reg);
            prstmt.setInt(3,semester);
            prstmt.setString(4,address);

           
            prstmt.addBatch();
        }
         rs = prstmt.executeBatch();
        
        if(acommit == false)
        {
            con.commit();
        }
      
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
          prstmt.close();
        }
    }
    
    //function for entries 5000 entries into the db using stored procedures
    public void storedProcedure(boolean acommit) throws SQLException
    {
         CallableStatement cstmt = null;;
        String SQL = "{call insert_student(?, ?, ?, ?)}";
         try
        {
        con.setAutoCommit(acommit);
     
        cstmt = con.prepareCall (SQL);
        String name = "";
      
        int reg = 0;
        int semester = 0;
        String address = "House #6, Street5, E-8, Isl";
        int[] rs ;
      
        for(int i=0; i < 10; i++)
        {
        name = getRandomName();
            reg = getRandomNumber();
            semester = getRandomSemester();

            cstmt.setString(1,name);
            cstmt.setInt(2,reg);
            cstmt.setInt(3,semester);
            cstmt.setString(4,address);

           
            cstmt.addBatch();
        }
         rs = cstmt.executeBatch();
     
        if(acommit == false)
        {
            con.commit();
        }
      
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            cstmt.close();
        }
    }
    
    
}
