/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab08_jdbc;

import java.sql.SQLException;

/**
 *
 * @author ABC
 */
public class Lab08_JDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Student s = new Student();
       long startTime ;
       long endTime ;
       
       long selectTrue;
       long selectFalse;
       long preparedTrue;
       long preparedFalse;
       long batchTrue;
       long batchFalse;
       long procTrue;
       long procFalse;
       try{
       //recording time for insert statement commint true
       startTime = System.currentTimeMillis();
       s.insert_statement(true);
       endTime= System.currentTimeMillis();

       selectTrue = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for Statement autocommit = true :"+ selectTrue + " milliseconds");
       s.truncate_students();
       
       
       
       //recording time for insert statement commit false
       startTime = System.currentTimeMillis();
       s.insert_statement(false);
       endTime= System.currentTimeMillis();

       selectFalse = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for Statement autocommit = false :"+selectFalse + " milliseconds");
       s.truncate_students();
       
        //recording time for insert prepared statement commint true
       startTime = System.currentTimeMillis();
       s.insert_PreparedStatement(true);
       endTime= System.currentTimeMillis();

       preparedTrue = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for Prepared Statement autocommit = true :"+ preparedTrue + " milliseconds");
       s.truncate_students();
       
       
       
       //recording time for insert statement commit false
       startTime = System.currentTimeMillis();
       s.insert_PreparedStatement(false);
       endTime= System.currentTimeMillis();

       preparedFalse = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for Prepared Statement autocommit = false :"+preparedFalse + " milliseconds");
       s.truncate_students();
       
       
       //recording time for insert batch commint true
       startTime = System.currentTimeMillis();
       s.insert_Batch(true);
       endTime= System.currentTimeMillis();

       batchTrue = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for Batch autocommit = true :"+ batchTrue + " milliseconds");
       s.truncate_students();
       
       
       
       //recording time for insert batch commit false
       startTime = System.currentTimeMillis();
       s.insert_Batch(false);
       endTime= System.currentTimeMillis();

       batchFalse = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for Batch autocommit = false :"+batchFalse + " milliseconds");
       s.truncate_students();
       
   
   //recording time for stored procdure insert statement commit true
       startTime = System.currentTimeMillis();
       s.storedProcedure(true);
       endTime= System.currentTimeMillis();

       procTrue = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for stored procedure autocommit = True :"+procTrue + " milliseconds");
       s.truncate_students();
       
       
       //recording time for stored procdure insert statement commit false
       startTime = System.currentTimeMillis();
       s.storedProcedure(false);
       endTime= System.currentTimeMillis();

       procFalse = (endTime - startTime); 
       
       System.out.println("Rows entered: " + s.getRowNum());
       System.out.println("Time taken for stored procedure autocommit = false :"+procFalse + " milliseconds");
     //  s.truncate_students();
       }
       catch(SQLException e)
       {
           System.out.println(e);
       }
    }
    
}
